using System;

namespace DeveloperSample.Algorithms
{
    public static class Algorithms
    {
        public static int GetFactorial(int n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }

            int factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *= i;
            }
            return factorial;
        }

        public static string FormatSeparators(params string[] items)
        {
            if (items == null)
            {
                throw new ArgumentNullException(nameof(items));
            }

            int count = items.Length;
        
            if (count == 0)
            {
                return string.Empty;
            }

            if (count == 1)
            {
                return items[0];
            }

            if (count == 2)
            {
                return $"{items[0]} and {items[1]}";
            }

            var stringList = new List<string>();

            // All items except the last one
            for (int i = 0; i < count - 1; i++)
            {
                parts.Add(items[i]);
            }

            // Combine items except the last one with commas
            var combined = string.Join(", ", parts);

            // Append the last item with an and 
            return $"{combined} and {items[count - 1]}";
        }
    }
}