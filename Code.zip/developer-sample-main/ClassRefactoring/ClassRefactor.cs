using System;

namespace DeveloperSample.ClassRefactoring
{
    public enum SwallowType
    {
        African, 
        European
    }

    public enum SwallowLoad
    {
        None, 
        Coconut
    }

    public class SwallowFactory
    {
        public Swallow GetSwallow(SwallowType swallowType) => new Swallow(swallowType);
    }

    public class Swallow
    {
        private readonly IAirspeed _airspeed;

        public SwallowType Type { get; }
        public SwallowLoad Load { get; private set; }

        public Swallow(SwallowType swallowType)
        {
            Type = swallowType;
            _airspeed = swallowType switch
            {
                SwallowType.African => new AfricanAirspeed(),
                SwallowType.European => new EuropeanAirspeed(),
                _ => throw new InvalidOperationException("Unsupported swallow type")
            };
        }

        public void ApplyLoad(SwallowLoad load)
        {
            Load = load;
        }

        public double GetAirspeedVelocity()
        {
            return _airspeed.CalculateAirspeed(Load);
        }
    }

    // Define strategy interface
    public interface IAirspeed
    {
        double CalculateAirspeed(SwallowLoad load);
    }

    // Logic for African swallows
    public class AfricanAirspeed : IAirspeed
    {
        public double CalculateAirspeed(SwallowLoad load)
        {
            return load switch
            {
                SwallowLoad.None => 22,
                SwallowLoad.Coconut => 18,
                _ => throw new InvalidOperationException("Unsupported load")
            };
        }
    }

    // Logic for European swallows
    public class EuropeanAirspeed : IAirspeed
    {
        public double CalculateAirspeed(SwallowLoad load)
        {
            return load switch
            {
                SwallowLoad.None => 20,
                SwallowLoad.Coconut => 16,
                _ => throw new InvalidOperationException("Unsupported load")
            };
        }
    }
}