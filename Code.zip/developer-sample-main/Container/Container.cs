using System;

namespace DeveloperSample.Container
{
    public class Container
    {
        private readonly Dictionary<Type, Type> _bindings = new Dictionary<Type, Type>();

        public void Bind(Type serviceType, Type implementationType)
        {
            if (!serviceType.IsInterface)
                throw new ArgumentException("Service type must be an interface.", nameof(serviceType));
            
            if (!serviceType.IsAssignableFrom(implementationType))
                throw new ArgumentException("Implementation type must implement the service type.", nameof(implementationType));
            
            _bindings[serviceType] = implementationType;
        }

        public T Get<T>()
        {
            var serviceType = typeof(T);
            if (!_bindings.TryGetValue(serviceType, out var implementationType))
                throw new InvalidOperationException($"No binding found for {serviceType}");

            return (T)Activator.CreateInstance(implementationType);
        }    
    }
}