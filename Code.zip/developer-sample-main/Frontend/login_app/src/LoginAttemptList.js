import React, { useState } from "react";
import "./LoginAttemptList.css";

const LoginAttempt = ({ login, timestamp }) => (
	<li>
	  <strong>Login:</strong> {login} <br />
	  <strong>Timestamp:</strong> {timestamp}
	</li>
  );
  
  const LoginAttemptList = ({ attempts }) => {
	const [filter, setFilter] = useState('');
  
	// Handle filter input change
	const handleFilterChange = (event) => {
	  setFilter(event.target.value);
	};
  
	// Filter attempts based on the filter input
	const filteredAttempts = attempts.filter((attempt) =>
	  attempt.login.toLowerCase().includes(filter.toLowerCase())
	);
  
	return (
	  <div className="Attempt-List-Main">
		<p>Recent activity</p>
		<input
		  type="text"
		  placeholder="Filter by login..."
		  value={filter}
		  onChange={handleFilterChange}
		/>
		<ul className="Attempt-List">
		  {filteredAttempts.length > 0 ? (
			filteredAttempts.map((attempt, index) => (
			  <LoginAttempt
				key={index}
				login={attempt.login}
				timestamp={attempt.timestamp}
			  />
			))
		  ) : (
			<li>No login attempts</li>
		  )}
		</ul>
	  </div>
	);
  };
  
  export default LoginAttemptList;