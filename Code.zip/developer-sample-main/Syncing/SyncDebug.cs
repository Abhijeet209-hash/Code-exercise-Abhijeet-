using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DeveloperSample.Syncing
{
    public class SyncDebug
    {
        public async Task<List<string>> InitializeList(IEnumerable<string> items)
        {
            var bag = new ConcurrentBag<string>();
            
            var tasks = items.Select(async item =>
            {
                var r = await Task.Run(() => item).ConfigureAwait(false);
                bag.Add(r);
            }).ToArray();

            await Task.WhenAll(tasks);

            return bag.ToList();
        }

          public async Task<Dictionary<int, string>> InitializeDictionary(Func<int, string> getItem)
        {
            var itemsToInitialize = Enumerable.Range(0, 100).ToList();
            var dictionary = new ConcurrentDictionary<int, string>();
            var items = new ConcurrentBag<int>();

            // Use a semaphore to control the degree of parallelism
            var options = new SemaphoreSlim(10);

            var tasks = itemsToInitialize.Select(async item =>
            {
                await options.WaitAsync();

                try
                {
                    var result = await Task.Run(async () =>
                    {
                        await Task.Delay(1); // Simulate async work
                        items.Add(item);
                        return getItem(item);
                    }).ConfigureAwait(false);

                    dictionary[item] = result;
                }
                finally
                {
                    options.Release();
                }
            }).ToArray();

            await Task.WhenAll(tasks);

            return dictionary.ToDictionary(kv => kv.Key, kv => kv.Value);
        }

    }
}